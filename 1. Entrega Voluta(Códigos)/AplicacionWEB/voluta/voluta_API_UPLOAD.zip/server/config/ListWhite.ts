export const permisos = [ 
    
    'http://localhost:4200',
    'http://localhost:4200/',
    'localhost:3000',
    'http://localhost:3000',
    'https://crpmusic.herokuapp.com',
    'https://crpmusic.herokuapp.com/'
 
];